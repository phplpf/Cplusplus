#pragma once
bool PeerScreenMouseKey(SOCKET s);
bool PeerScreenGet(SOCKET s);